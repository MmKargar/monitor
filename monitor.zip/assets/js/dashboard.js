import Vue from 'vue';
// import component
import day from './components/day';

const mycharts = new Vue({
    element: '#mycharts',
    components: {
        day
    }
});