<?php
// Composer AutoLoad
require_once '../vendor/autoload.php';
require_once 'database.php';
// Create The Mvc Structure
require_once 'core/App.php';
require_once 'core/Controller.php';