<?php

use illuminate\Database\Eloquent\Model as Eloquent;

class User  extends Eloquent
{
    // protected $timestaps = ['updated_at'  , 'created_at'];
    protected $guarded = [];
}